# Example Package

Module for creating an email address