def create_email_address(name, domain):
    return name + "@" + domain